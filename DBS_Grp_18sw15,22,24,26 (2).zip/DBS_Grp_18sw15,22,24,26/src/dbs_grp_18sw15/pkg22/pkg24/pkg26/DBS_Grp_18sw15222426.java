/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbs_grp_18sw15.pkg22.pkg24.pkg26;

/**
 *
 * @author Ibrahim
 */
public class DBS_Grp_18sw15222426 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       new SplashScreen().showSplash();
    }
    
}
