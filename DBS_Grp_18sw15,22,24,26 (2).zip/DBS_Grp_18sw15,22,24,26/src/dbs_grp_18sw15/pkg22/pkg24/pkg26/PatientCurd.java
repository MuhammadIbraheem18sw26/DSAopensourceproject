/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbs_grp_18sw15.pkg22.pkg24.pkg26;

import Connection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Ibrahim
 */
public class PatientCurd extends javax.swing.JFrame {

    Connection con = DBConnection.makeConnection();
    DefaultTableModel model;
    ResultSet rs;
    /**
     * Creates new form PatientCurd
     */
    public PatientCurd() {
        initComponents();
       
         model = (DefaultTableModel) patientTable.getModel();
          useCombo();
          showData();
    }

    public void useCombo() {

        try {
            PreparedStatement pst = con.prepareStatement("Select Doctor_Name from doctor");
           
             rs = pst.executeQuery();
           
            while (rs.next()) {
                docCombo.addItem(rs.getString("Doctor_Name"));
            }

        } catch (SQLException ex) {
        }
    }
        
       public void clearData(){
     patName.setText(null);
     patCont.setText(null);
     patAge.setText(null);
     docName.setText(null);
    patDisease.setText(null);
    lastName.setText(null);
    
     }  
       
       
     public void showData() {
        model.setRowCount(0);
        try {
            PreparedStatement pst = con.prepareStatement("Select * from patient");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Object[] object = {rs.getInt("Patient_Id"), rs.getString("Patient_Name"), rs.getString("Patient_LName"), rs.getString("Doctor_Name"), rs.getString("Patient_Age"),rs.getString("Patient_Disease"),rs.getString("Patient_Contact"),};
                model.addRow(object);
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }  
     }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        docCombo = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        patName = new javax.swing.JTextField();
        lastName = new javax.swing.JTextField();
        patAge = new javax.swing.JTextField();
        patDisease = new javax.swing.JTextField();
        patCont = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        patientTable = new javax.swing.JTable();
        addBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        docName = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("NAME");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setText("LAST NAME");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("DOCTOR");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 270, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setText("AGE");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 330, -1, -1));

        docCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                docComboActionPerformed(evt);
            }
        });
        jPanel1.add(docCombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 270, 110, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setText("DISEASE");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel6.setText("CONTACT NO");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 470, -1, -1));
        jPanel1.add(patName, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 110, 200, -1));

        lastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastNameActionPerformed(evt);
            }
        });
        jPanel1.add(lastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 180, 200, -1));
        jPanel1.add(patAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 330, 200, -1));
        jPanel1.add(patDisease, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 400, 200, -1));
        jPanel1.add(patCont, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 470, 200, -1));

        patientTable.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        patientTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Patient ID", "Name", "Last Name", "Refer To", "Age", "Disease", "Contact No"
            }
        ));
        patientTable.setSelectionBackground(new java.awt.Color(255, 51, 51));
        patientTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                patientTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(patientTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 110, 520, 380));

        addBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ButtonImages/button_add.png"))); // NOI18N
        addBtn.setContentAreaFilled(false);
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });
        jPanel1.add(addBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 573, -1, 50));

        updateBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ButtonImages/button_update (1)_1.png"))); // NOI18N
        updateBtn.setContentAreaFilled(false);
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });
        jPanel1.add(updateBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 570, -1, -1));

        deleteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ButtonImages/button_delete_1.png"))); // NOI18N
        deleteBtn.setContentAreaFilled(false);
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });
        jPanel1.add(deleteBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 570, -1, -1));

        docName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                docNameActionPerformed(evt);
            }
        });
        jPanel1.add(docName, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 270, 90, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel7.setText("ADD/REMOVE");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/patientBackpic.jpg"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lastNameActionPerformed

    private void docComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_docComboActionPerformed
      docName.setText(docCombo.getSelectedItem().toString());
    }//GEN-LAST:event_docComboActionPerformed

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        if (patName.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Enter Patient Name");
        } 
    else if (patientTable.getSelectedRow() < 0) {
    
    {
            String patient_Name = patName.getText();
            String last_Name= lastName.getText();
            String doc_Name= docName.getText();
            String patient_Age= patAge.getText();
            String patient_Disease= patDisease.getText();
            String patient_Cont= patCont.getText();
            
            
            

            try {
                PreparedStatement pst = con.prepareStatement("Insert into patient (Patient_Name,Patient_LName,Doctor_Name,Patient_Age,Patient_Disease,Patient_Contact) values(?,?,?,?,?,?)");
                pst.setString(1, patient_Name);
                pst.setString(2, last_Name);
                pst.setString(3, doc_Name);
                pst.setString(4, patient_Age);
                pst.setString(5, patient_Disease);
                 pst.setString(6, patient_Cont); 
   
              

                int check = pst.executeUpdate();
                if (check > 0) {
                    JOptionPane.showMessageDialog(this, "Record added");
                } else {
                    JOptionPane.showMessageDialog(this, "Record not added");
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            
           showData();
           clearData();
        } 
    } 
   
    
    else {
            JOptionPane.showMessageDialog(this, "Duplicate record not allowed");
        }
    }//GEN-LAST:event_addBtnActionPerformed

    private void patientTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_patientTableMouseClicked
       model = (DefaultTableModel)patientTable.getModel();
       int select=patientTable.getSelectedRow();
       
       patName.setText(model.getValueAt(select,1).toString());
        lastName.setText(model.getValueAt(select,2).toString());
         docName.setText(model.getValueAt(select,3).toString());
         patAge.setText(model.getValueAt(select,4).toString());
        patDisease.setText(model.getValueAt(select,5).toString());
          patCont.setText(model.getValueAt(select,6).toString());
    }//GEN-LAST:event_patientTableMouseClicked

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
          if(patName.getText().equals("") )
       {
           JOptionPane.showMessageDialog(this,"Select Row First");
       } 
        
        else {
            try {
            
            model = (DefaultTableModel)patientTable.getModel();
             int select=patientTable.getSelectedRow();
            String set=(patientTable.getModel().getValueAt(select, 0).toString());
            String restName=patName.getText();
            String restLName=lastName.getText();
            String restCont=patCont.getText();
            String restAge=patAge.getText();
            String restDoc=docName.getText();
            String restDisease=patDisease.getText();
            
             
            PreparedStatement pst = con.prepareStatement("Update patient SET Patient_Name='"+restName+"',Patient_LName='"+restLName+"', Doctor_Name='"+restDoc+"' ,Patient_Age='"+restAge+"' ,Patient_Contact='"+restCont+"'    where Patient_Id="+set);
          
              pst.executeUpdate();
           
   
             JOptionPane.showMessageDialog(this, "Record  updated");
             

        } 
         
         catch (SQLException ex) {
           
        }
       showData();
        clearData();
    }
        
        
    }//GEN-LAST:event_updateBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
    if(patName.getText().equals(""))
       {
           JOptionPane.showMessageDialog(this,"Select Row First");
       } 
          else{
            try {
             
            model= (DefaultTableModel)patientTable.getModel();
            int select=patientTable.getSelectedRow();
            String set=(patientTable.getModel().getValueAt(select, 0).toString());
             PreparedStatement pst = con.prepareStatement("Delete from patient where Patient_Id="+set);
      
            int check = pst.executeUpdate();
            if (check > 0) {
                JOptionPane.showMessageDialog(this, "Record deleted");
            } else {
                JOptionPane.showMessageDialog(this, "Record not deleted");
            }

        } catch (SQLException ex) {
        }
        showData();
        clearData();
        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void docNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_docNameActionPerformed
        
    }//GEN-LAST:event_docNameActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PatientCurd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PatientCurd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PatientCurd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PatientCurd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PatientCurd().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addBtn;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JComboBox<String> docCombo;
    private javax.swing.JTextField docName;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lastName;
    private javax.swing.JTextField patAge;
    private javax.swing.JTextField patCont;
    private javax.swing.JTextField patDisease;
    private javax.swing.JTextField patName;
    private javax.swing.JTable patientTable;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
